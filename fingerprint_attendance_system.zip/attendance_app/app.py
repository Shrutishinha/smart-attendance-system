from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, Response
import sqlite3
import hashlib
import csv
import io
import os
from datetime import datetime, date
from database_setup import init_db, get_db, DB_PATH
import random
import string

app = Flask(__name__)
app.secret_key = 'biometric_attendance_secret_2024'

# ─── AUTH ──────────────────────────────────────────────────────────────────────

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'admin' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/', methods=['GET', 'POST'])
def login():
    if 'admin' in session:
        return redirect(url_for('dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        hashed = hashlib.sha256(password.encode()).hexdigest()
        db = get_db()
        user = db.execute('SELECT * FROM admin WHERE username=? AND password=?', (username, hashed)).fetchone()
        db.close()
        if user:
            session['admin'] = username
            return redirect(url_for('dashboard'))
        else:
            error = 'Invalid username or password.'
    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('admin', None)
    return redirect(url_for('login'))

# ─── DASHBOARD ─────────────────────────────────────────────────────────────────

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    total_students = db.execute('SELECT COUNT(*) FROM students').fetchone()[0]
    total_classes  = db.execute('SELECT COUNT(*) FROM classes').fetchone()[0]
    today_str = date.today().strftime('%Y-%m-%d')
    today_attendance = db.execute('SELECT COUNT(*) FROM attendance WHERE date=?', (today_str,)).fetchone()[0]
    total_attendance = db.execute('SELECT COUNT(*) FROM attendance').fetchone()[0]

    # Recent 5 attendance records
    recent = db.execute('''
        SELECT a.date, a.time, s.name, s.student_id, c.name as class_name, a.status
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        JOIN classes c ON a.class_id = c.id
        ORDER BY a.marked_at DESC LIMIT 5
    ''').fetchall()

    # Attendance per class today
    class_stats = db.execute('''
        SELECT c.name, COUNT(a.id) as cnt
        FROM classes c
        LEFT JOIN attendance a ON c.id = a.class_id AND a.date = ?
        GROUP BY c.id
    ''', (today_str,)).fetchall()

    # Weekly attendance trend (last 7 days)
    weekly = db.execute('''
        SELECT date, COUNT(*) as cnt FROM attendance
        WHERE date >= date('now', '-6 days')
        GROUP BY date ORDER BY date
    ''').fetchall()

    db.close()
    return render_template('dashboard.html',
        total_students=total_students,
        total_classes=total_classes,
        today_attendance=today_attendance,
        total_attendance=total_attendance,
        recent=recent,
        class_stats=class_stats,
        weekly=weekly,
        today=today_str
    )

# ─── STUDENTS ──────────────────────────────────────────────────────────────────

@app.route('/students')
@login_required
def students():
    db = get_db()
    search = request.args.get('search', '')
    class_filter = request.args.get('class_id', '')
    query = '''
        SELECT s.*, c.name as class_name,
               (SELECT COUNT(*) FROM attendance a WHERE a.student_id=s.id) as attendance_count
        FROM students s LEFT JOIN classes c ON s.class_id=c.id
        WHERE 1=1
    '''
    params = []
    if search:
        query += ' AND (s.name LIKE ? OR s.student_id LIKE ? OR s.email LIKE ?)'
        params += [f'%{search}%', f'%{search}%', f'%{search}%']
    if class_filter:
        query += ' AND s.class_id=?'
        params.append(class_filter)
    query += ' ORDER BY s.registered_at DESC'
    student_list = db.execute(query, params).fetchall()
    classes = db.execute('SELECT * FROM classes ORDER BY name').fetchall()
    db.close()
    return render_template('students.html', students=student_list, classes=classes,
                           search=search, class_filter=class_filter)

@app.route('/students/add', methods=['POST'])
@login_required
def add_student():
    sid    = request.form.get('student_id', '').strip()
    name   = request.form.get('name', '').strip()
    email  = request.form.get('email', '').strip()
    cls    = request.form.get('class_id', '')
    fp_id  = 'FP' + ''.join(random.choices(string.digits, k=6))
    if not sid or not name:
        flash('Student ID and Name are required.', 'error')
        return redirect(url_for('students'))
    db = get_db()
    try:
        db.execute('INSERT INTO students (student_id, name, email, class_id, fingerprint_id) VALUES (?,?,?,?,?)',
                   (sid, name, email or None, cls or None, fp_id))
        db.commit()
        flash(f'Student {name} registered successfully! Fingerprint ID: {fp_id}', 'success')
    except sqlite3.IntegrityError:
        flash('Student ID already exists.', 'error')
    db.close()
    return redirect(url_for('students'))

@app.route('/students/delete/<int:sid>', methods=['POST'])
@login_required
def delete_student(sid):
    db = get_db()
    db.execute('DELETE FROM attendance WHERE student_id=?', (sid,))
    db.execute('DELETE FROM students WHERE id=?', (sid,))
    db.commit()
    db.close()
    flash('Student deleted.', 'success')
    return redirect(url_for('students'))

@app.route('/students/edit/<int:sid>', methods=['POST'])
@login_required
def edit_student(sid):
    name  = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip()
    cls   = request.form.get('class_id', '')
    db = get_db()
    db.execute('UPDATE students SET name=?, email=?, class_id=? WHERE id=?',
               (name, email, cls or None, sid))
    db.commit()
    db.close()
    flash('Student updated successfully.', 'success')
    return redirect(url_for('students'))

# ─── CLASSES ───────────────────────────────────────────────────────────────────

@app.route('/classes')
@login_required
def classes():
    db = get_db()
    class_list = db.execute('''
        SELECT c.*, COUNT(s.id) as student_count
        FROM classes c LEFT JOIN students s ON c.id=s.class_id
        GROUP BY c.id ORDER BY c.name
    ''').fetchall()
    db.close()
    return render_template('classes.html', classes=class_list)

@app.route('/classes/add', methods=['POST'])
@login_required
def add_class():
    name = request.form.get('name', '').strip()
    desc = request.form.get('description', '').strip()
    if not name:
        flash('Class name is required.', 'error')
        return redirect(url_for('classes'))
    db = get_db()
    db.execute('INSERT INTO classes (name, description) VALUES (?,?)', (name, desc))
    db.commit()
    db.close()
    flash(f'Class "{name}" created.', 'success')
    return redirect(url_for('classes'))

@app.route('/classes/delete/<int:cid>', methods=['POST'])
@login_required
def delete_class(cid):
    db = get_db()
    db.execute('DELETE FROM classes WHERE id=?', (cid,))
    db.commit()
    db.close()
    flash('Class deleted.', 'success')
    return redirect(url_for('classes'))

# ─── ATTENDANCE ─────────────────────────────────────────────────────────────────

@app.route('/attendance')
@login_required
def attendance():
    db = get_db()
    selected_date  = request.args.get('date', date.today().strftime('%Y-%m-%d'))
    selected_class = request.args.get('class_id', '')
    classes = db.execute('SELECT * FROM classes ORDER BY name').fetchall()

    query = '''
        SELECT a.id, s.name, s.student_id, c.name as class_name,
               a.date, a.time, a.status
        FROM attendance a
        JOIN students s ON a.student_id=s.id
        JOIN classes c ON a.class_id=c.id
        WHERE a.date=?
    '''
    params = [selected_date]
    if selected_class:
        query += ' AND a.class_id=?'
        params.append(selected_class)
    query += ' ORDER BY a.time DESC'
    records = db.execute(query, params).fetchall()

    students = db.execute('''
        SELECT s.id, s.name, s.student_id, s.fingerprint_id, c.name as class_name, s.class_id
        FROM students s LEFT JOIN classes c ON s.class_id=c.id
        ORDER BY s.name
    ''').fetchall()
    db.close()
    return render_template('attendance.html',
        records=records, classes=classes, students=students,
        selected_date=selected_date, selected_class=selected_class)

@app.route('/attendance/mark', methods=['POST'])
@login_required
def mark_attendance():
    student_id = request.form.get('student_id')
    class_id   = request.form.get('class_id')
    att_date   = request.form.get('date', date.today().strftime('%Y-%m-%d'))
    att_time   = datetime.now().strftime('%H:%M:%S')
    status     = request.form.get('status', 'present')

    if not student_id or not class_id:
        flash('Student and Class are required.', 'error')
        return redirect(url_for('attendance'))

    db = get_db()
    existing = db.execute(
        'SELECT id FROM attendance WHERE student_id=? AND class_id=? AND date=?',
        (student_id, class_id, att_date)
    ).fetchone()
    if existing:
        flash('Attendance already marked for this student today.', 'error')
    else:
        db.execute('INSERT INTO attendance (student_id, class_id, date, time, status) VALUES (?,?,?,?,?)',
                   (student_id, class_id, att_date, att_time, status))
        db.commit()
        student = db.execute('SELECT name FROM students WHERE id=?', (student_id,)).fetchone()
        flash(f'✅ Attendance marked for {student["name"]}', 'success')
    db.close()
    return redirect(url_for('attendance', date=att_date, class_id=class_id))

@app.route('/attendance/simulate', methods=['POST'])
@login_required
def simulate_fingerprint():
    data       = request.get_json()
    fp_id      = data.get('fingerprint_id')
    class_id   = data.get('class_id')
    att_date   = date.today().strftime('%Y-%m-%d')
    att_time   = datetime.now().strftime('%H:%M:%S')

    db = get_db()
    student = db.execute('SELECT * FROM students WHERE fingerprint_id=?', (fp_id,)).fetchone()
    if not student:
        db.close()
        return jsonify({'success': False, 'message': 'Fingerprint not recognized.'})

    if not class_id:
        class_id = student['class_id']

    existing = db.execute(
        'SELECT id FROM attendance WHERE student_id=? AND class_id=? AND date=?',
        (student['id'], class_id, att_date)
    ).fetchone()
    if existing:
        db.close()
        return jsonify({'success': False, 'message': f'{student["name"]} already marked today.'})

    db.execute('INSERT INTO attendance (student_id, class_id, date, time, status) VALUES (?,?,?,?,?)',
               (student['id'], class_id, att_date, att_time, 'present'))
    db.commit()
    db.close()
    return jsonify({'success': True, 'message': f'✅ {student["name"]} marked present!', 'name': student['name']})

@app.route('/attendance/delete/<int:aid>', methods=['POST'])
@login_required
def delete_attendance(aid):
    db = get_db()
    db.execute('DELETE FROM attendance WHERE id=?', (aid,))
    db.commit()
    db.close()
    flash('Attendance record deleted.', 'success')
    return redirect(url_for('attendance'))

# ─── REPORTS ───────────────────────────────────────────────────────────────────

@app.route('/reports')
@login_required
def reports():
    db = get_db()
    classes = db.execute('SELECT * FROM classes ORDER BY name').fetchall()
    students = db.execute('SELECT id, name, student_id FROM students ORDER BY name').fetchall()

    from_date = request.args.get('from_date', '')
    to_date   = request.args.get('to_date', '')
    class_id  = request.args.get('class_id', '')
    student_id = request.args.get('student_id', '')

    query = '''
        SELECT a.date, a.time, s.name, s.student_id, c.name as class_name, a.status
        FROM attendance a
        JOIN students s ON a.student_id=s.id
        JOIN classes c ON a.class_id=c.id
        WHERE 1=1
    '''
    params = []
    if from_date:
        query += ' AND a.date >= ?'; params.append(from_date)
    if to_date:
        query += ' AND a.date <= ?'; params.append(to_date)
    if class_id:
        query += ' AND a.class_id=?'; params.append(class_id)
    if student_id:
        query += ' AND a.student_id=?'; params.append(student_id)
    query += ' ORDER BY a.date DESC, a.time DESC'

    records = db.execute(query, params).fetchall()

    # Summary stats
    summary = db.execute('''
        SELECT s.name, s.student_id,
               COUNT(a.id) as total,
               SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) as present_count
        FROM students s
        LEFT JOIN attendance a ON s.id=a.student_id
        GROUP BY s.id ORDER BY s.name
    ''').fetchall()

    db.close()
    return render_template('reports.html',
        records=records, classes=classes, students=students, summary=summary,
        from_date=from_date, to_date=to_date, class_id=class_id, student_id=student_id)

@app.route('/reports/export')
@login_required
def export_csv():
    db = get_db()
    from_date  = request.args.get('from_date', '')
    to_date    = request.args.get('to_date', '')
    class_id   = request.args.get('class_id', '')
    student_id = request.args.get('student_id', '')

    query = '''
        SELECT a.date, a.time, s.student_id, s.name, c.name as class_name, a.status
        FROM attendance a
        JOIN students s ON a.student_id=s.id
        JOIN classes c ON a.class_id=c.id
        WHERE 1=1
    '''
    params = []
    if from_date: query += ' AND a.date>=?'; params.append(from_date)
    if to_date:   query += ' AND a.date<=?'; params.append(to_date)
    if class_id:  query += ' AND a.class_id=?'; params.append(class_id)
    if student_id: query += ' AND a.student_id=?'; params.append(student_id)
    query += ' ORDER BY a.date DESC'

    records = db.execute(query, params).fetchall()
    db.close()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Date', 'Time', 'Student ID', 'Student Name', 'Class', 'Status'])
    for r in records:
        writer.writerow([r['date'], r['time'], r['student_id'], r['name'], r['class_name'], r['status']])

    output.seek(0)
    filename = f'attendance_report_{date.today()}.csv'
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename={filename}'})

# ─── API ───────────────────────────────────────────────────────────────────────

@app.route('/api/students')
@login_required
def api_students():
    db = get_db()
    data = db.execute('''
        SELECT s.id, s.name, s.student_id, s.fingerprint_id, c.name as class_name, s.class_id
        FROM students s LEFT JOIN classes c ON s.class_id=c.id ORDER BY s.name
    ''').fetchall()
    db.close()
    return jsonify([dict(r) for r in data])

@app.route('/api/dashboard_stats')
@login_required
def api_dashboard_stats():
    db = get_db()
    today_str = date.today().strftime('%Y-%m-%d')
    weekly = db.execute('''
        SELECT date, COUNT(*) as cnt FROM attendance
        WHERE date >= date('now', '-6 days')
        GROUP BY date ORDER BY date
    ''').fetchall()
    db.close()
    return jsonify({'weekly': [dict(r) for r in weekly]})

# ─── MAIN ──────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    if not os.path.exists(DB_PATH):
        init_db()
    app.run(debug=True, port=5000)
