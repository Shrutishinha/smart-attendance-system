// ═══════════════════════════════════════════
//  BIOATTEND — Frontend Script
// ═══════════════════════════════════════════

// ── CLOCK ──────────────────────────────────
function updateClock() {
  const now = new Date();
  const time = now.toTimeString().slice(0, 8);
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
  const clockEl = document.getElementById('clock');
  const dateEl  = document.getElementById('datebadge');
  if (clockEl) clockEl.textContent = time;
  if (dateEl)  dateEl.textContent  = dateStr;
}
updateClock();
setInterval(updateClock, 1000);

// ── SIDEBAR TOGGLE ──────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar')?.classList.toggle('open');
}
document.addEventListener('click', (e) => {
  const sidebar = document.getElementById('sidebar');
  if (!sidebar) return;
  if (!sidebar.contains(e.target) && !e.target.classList.contains('menu-toggle')) {
    sidebar.classList.remove('open');
  }
});

// ── MODALS ──────────────────────────────────
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('open');
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}
// Close modal on overlay click
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});
// ESC to close
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(el => el.classList.remove('open'));
  }
});

// ── AUTO DISMISS FLASHES ────────────────────
setTimeout(() => {
  document.querySelectorAll('.flash').forEach(el => {
    el.style.transition = 'opacity 0.5s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 500);
  });
}, 4000);

// ── ANIMATE STAT NUMBERS ──────────────────
function animateCounters() {
  document.querySelectorAll('.stat-num').forEach(el => {
    const target = parseInt(el.textContent, 10);
    if (isNaN(target)) return;
    let start = 0;
    const step = Math.ceil(target / 25);
    const interval = setInterval(() => {
      start += step;
      if (start >= target) { el.textContent = target; clearInterval(interval); }
      else el.textContent = start;
    }, 30);
  });
}
document.addEventListener('DOMContentLoaded', animateCounters);

// ── SET TODAY DATE IN INPUTS ─────────────────
document.addEventListener('DOMContentLoaded', () => {
  const today = new Date().toISOString().slice(0, 10);
  document.querySelectorAll('input[type="date"]').forEach(el => {
    if (!el.value) el.value = today;
  });
});
