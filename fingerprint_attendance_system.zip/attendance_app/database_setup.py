import sqlite3
import hashlib
import os

DB_PATH = os.path.join(os.path.dirname(__file__), 'attendance.db')

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    # Admin table
    c.execute('''
        CREATE TABLE IF NOT EXISTS admin (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Classes table
    c.execute('''
        CREATE TABLE IF NOT EXISTS classes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    # Students table
    c.execute('''
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            email TEXT,
            class_id INTEGER,
            fingerprint_id TEXT UNIQUE,
            registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (class_id) REFERENCES classes(id)
        )
    ''')

    # Attendance table
    c.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            class_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            status TEXT DEFAULT 'present',
            marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id),
            FOREIGN KEY (class_id) REFERENCES classes(id)
        )
    ''')

    # Seed admin
    pwd = hashlib.sha256('admin123'.encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO admin (username, password) VALUES (?, ?)', ('admin', pwd))

    # Seed sample classes
    classes = [
        ('Computer Science - A', 'Morning batch CS'),
        ('Computer Science - B', 'Afternoon batch CS'),
        ('Data Science', 'DS specialization'),
        ('Web Development', 'Full stack web dev'),
    ]
    for cls in classes:
        c.execute('INSERT OR IGNORE INTO classes (name, description) VALUES (?, ?)', cls)

    # Seed sample students
    students = [
        ('CS001', 'Aarav Sharma', 'aarav@college.edu', 1, 'FP001'),
        ('CS002', 'Priya Patel', 'priya@college.edu', 1, 'FP002'),
        ('CS003', 'Rohan Verma', 'rohan@college.edu', 1, 'FP003'),
        ('CS004', 'Sneha Gupta', 'sneha@college.edu', 2, 'FP004'),
        ('CS005', 'Vikram Singh', 'vikram@college.edu', 2, 'FP005'),
        ('CS006', 'Ananya Rao', 'ananya@college.edu', 3, 'FP006'),
        ('CS007', 'Karan Mehta', 'karan@college.edu', 3, 'FP007'),
        ('CS008', 'Divya Nair', 'divya@college.edu', 4, 'FP008'),
        ('CS009', 'Arjun Kapoor', 'arjun@college.edu', 4, 'FP009'),
        ('CS010', 'Meera Joshi', 'meera@college.edu', 1, 'FP010'),
    ]
    for s in students:
        c.execute('''INSERT OR IGNORE INTO students (student_id, name, email, class_id, fingerprint_id)
                     VALUES (?, ?, ?, ?, ?)''', s)

    conn.commit()
    conn.close()
    print("✅ Database initialized successfully!")
    print("🔐 Login: admin / admin123")

if __name__ == '__main__':
    init_db()
